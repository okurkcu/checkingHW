package com.example.ozankurkcuhw2.view.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.ozankurkcuhw2.view.util.Constants

@Database(entities = [Car::class], version = 1)
abstract class CarRoomDatabase : RoomDatabase() {
    abstract fun carDao(): CarDAO

    companion object{
        @Volatile
        private var INSTANCE: CarRoomDatabase?=null

        fun getDatabase(context: Context): CarRoomDatabase{
            val tempInstance = INSTANCE

            if(tempInstance != null){
                return tempInstance
            }

            synchronized(this){
                val instance = Room.databaseBuilder(context.applicationContext, CarRoomDatabase::class.java, Constants.DATABASENAME).build()
                INSTANCE = instance
                return instance
            }
        }
    }
}