package com.example.ozankurkcuhw2.view.util

object Constants {
    const val DATABASENAME="carDB"
    const val TABLENAME="cars"
}