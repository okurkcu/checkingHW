package com.example.ozankurkcuhw2.view.database

import android.widget.ImageView
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.ozankurkcuhw2.view.util.Constants
import java.io.Serializable

@Entity(tableName = Constants.TABLENAME)
class Car (
    @PrimaryKey(autoGenerate = true)
    var carYear: Int,
    var carName: String,
    var carDetail: String) : Serializable
{
    override fun toString(): String {
        return "Car(carName='$carName', carDetail='$carDetail'"
    }
}