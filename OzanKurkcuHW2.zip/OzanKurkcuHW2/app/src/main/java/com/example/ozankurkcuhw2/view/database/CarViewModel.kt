package com.example.ozankurkcuhw2.view.database

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CarViewModel(application: Application) : AndroidViewModel(application) {
    val readAllData: List<Car>
    private val repository: CarRepos

    init {
        val carDao = CarRoomDatabase.getDatabase(application).carDao()
        repository = CarRepos(carDao)
        readAllData = repository.readAllData
    }

    fun getAllCars(): List<Car>{
        return repository.getAllCars()
    }

    fun addCar(c: Car){
        repository.insertCar(c)
    }

    fun deleteCar(c: Car){
        repository.deleteCar(c)
    }

    fun deleteAllCars(){
        viewModelScope.launch(Dispatchers.IO){
            repository.deleteAllCars()
        }
    }
}