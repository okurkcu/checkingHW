package com.example.ozankurkcuhw2.view.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ozankurkcuhw2.databinding.ActivityCarDetailsBinding
import com.example.ozankurkcuhw2.view.CarDetailsActivity
import com.example.ozankurkcuhw2.view.database.Car
import java.text.FieldPosition

class CarRecyclerViewAdapter(val carList: ArrayList<Car>) : RecyclerView.Adapter<CarRecyclerViewAdapter.CarHolder>() {
    class CarHolder(val binding: RecyclerRowBinding) : RecyclerView.ViewHolder(binding.root){

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarHolder {
        val binding = RecyclerRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CarHolder((binding))
    }

    override fun onBindViewHolder(holder: CarHolder, position: Int) {
        holder.binding.recyclerRowTextView.text = carList.get(position).carName
        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, CarDetailsActivity::class.java)
            intent.putExtra("recipe", carList.get(position))
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return carList.size
    }
}