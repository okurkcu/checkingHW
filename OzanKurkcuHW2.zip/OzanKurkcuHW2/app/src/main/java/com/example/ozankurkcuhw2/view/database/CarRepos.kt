package com.example.ozankurkcuhw2.view.database

class CarRepos(private val CarDAO: CarDAO) {
    val readAllData: List<Car> = CarDAO.getAllCars()

    fun insertCar(c: Car){
        CarDAO.insertCar(c)
    }

    fun deleteCar(c: Car){
        CarDAO.deleteCar(c)
    }

    fun deleteAllCars(){
        CarDAO.deleteAllCars()
    }

    fun getAllCars(): List<Car>{
        return CarDAO.getAllCars()
    }
}