package com.example.ozankurkcuhw2.view.database

import androidx.core.view.WindowInsetsCompat.Type.InsetsType
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.ozankurkcuhw2.view.util.Constants

@Dao
interface CarDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertCar(car: Car)

    @Delete
    fun deleteCar(car: Car)

    @Query("DELETE FROM ${Constants.TABLENAME}")
    fun deleteAllCars()

    @Query("SELECT * FROM ${Constants.TABLENAME} ORDER BY carName DESC")
    fun getAllCars(): List<Car>
}