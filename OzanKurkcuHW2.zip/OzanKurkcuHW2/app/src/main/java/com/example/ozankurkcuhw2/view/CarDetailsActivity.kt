package com.example.ozankurkcuhw2.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.WindowManager
import com.example.ozankurkcuhw2.databinding.ActivityCarDetailsBinding
import com.example.ozankurkcuhw2.view.database.Car

class CarDetailsActivity : AppCompatActivity() {
    lateinit var binding:ActivityCarDetailsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCarDetailsBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        getSupportActionBar()?.hide();

        @Suppress("DEPRECATION")
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)

        val intent = intent

        val car = intent.getSerializableExtra("car") as Car
        binding.tvCarName.text = car.carName

        binding.btnBack.setOnClickListener{
            finish()
        }
    }
}