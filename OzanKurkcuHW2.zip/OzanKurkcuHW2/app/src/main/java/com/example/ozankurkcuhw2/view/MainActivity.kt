package com.example.ozankurkcuhw2.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.GestureDetector
import android.view.GestureDetector.OnDoubleTapListener
import android.view.GestureDetector.OnGestureListener
import android.view.MotionEvent
import android.view.WindowManager
import androidx.core.view.GestureDetectorCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ozankurkcuhw2.databinding.ActivityMainBinding
import com.example.ozankurkcuhw2.view.adapter.CarRecyclerViewAdapter
import com.example.ozankurkcuhw2.view.database.Car

class MainActivity : AppCompatActivity(), OnGestureListener, OnDoubleTapListener {
    lateinit var binding: ActivityMainBinding
    private lateinit var carList : ArrayList<Car>
    val TAG: String ="GESTURE"
    var gDetector: GestureDetectorCompat? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        getSupportActionBar()?.hide();

        @Suppress("DEPRECATION")
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)

        gDetector = GestureDetectorCompat(this, this)
        gDetector?.setOnDoubleTapListener(this)

        carList = ArrayList<Car>()

        val ford = Car(2023,"Ford", "Innovative American automaker crafting reliable vehicles with iconic designs.")
        val tesla = Car(2024,"Tesla", "Innovative electric vehicles redefining automotive standards.")

        carList.add(ford)
        carList.add(tesla)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        val adapter = CarRecyclerViewAdapter(carList)
        binding.recyclerView.adapter = adapter

        binding.btnDelete.setOnClickListener{
            //val intent = Intent(this, AddingDataActivity::class.java)
            startActivity(intent)
        }

        binding.btnAdd.setOnClickListener{
            val intent = Intent(this@MainActivity, CarDetailsActivity::class.java)
            startActivity(intent)
        }
    }


    override fun onTouchEvent(event: MotionEvent): Boolean {
        gDetector?.onTouchEvent(event)
        return super.onTouchEvent(event)
    }

    inner class CustomGesture: GestureDetector.SimpleOnGestureListener() {

        override fun onLongPress(e: MotionEvent) {
            Log.i(TAG, "onLongPress")
        }

        override fun onFling(
            e1: MotionEvent?,
            e2: MotionEvent,
            velocityX: Float,
            velocityY: Float
        ): Boolean {
            Log.i(TAG, "onFling")
            return false
        }
        override fun onDoubleTapEvent(e: MotionEvent): Boolean {
            Log.i(TAG, "onDoubleTapEvent")
            return true
        }
    }
}